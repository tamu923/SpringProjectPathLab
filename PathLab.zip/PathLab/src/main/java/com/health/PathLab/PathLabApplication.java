package com.health.PathLab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PathLabApplication {

	public static void main(String[] args) {
		SpringApplication.run(PathLabApplication.class, args);
	}

}

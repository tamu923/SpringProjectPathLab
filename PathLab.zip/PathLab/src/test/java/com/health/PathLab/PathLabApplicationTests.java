package com.health.PathLab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PathLabApplicationTests {

	@Test
	void contextLoads() {
	}

}
